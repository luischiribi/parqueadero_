<?php 
namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\Vehiculo;
class Parqueadero extends Controller{

    public function index()
    {
        $car = new Vehiculo();
        $datos['datos_veh']=$car->findAll();
        return view('consultar',$datos);
    }

    public function agregar()
    {

        return view('agregar');
    }
    public function insertar()
    {
       
        $car = new Vehiculo();

        $data=[
            'placa' => $_POST['placa'],
            'vehiculo' => $_POST['vehiculo'],
            'nombreCon' => $_POST['nombreCon'],
            'apellidoCon' => $_POST['apellidoCon'],
            'tiempo' => $_POST['tiempo'],
            'espacio' => $_POST['espacio']
        ];

        $car->insert($data);
        return redirect()->to(base_url());
       
        

        
    }
    public function eliminar($id=null)
    {

       $car = new Vehiculo();
        $car->delete($id);

        
        return redirect()->to(base_url());
    }
    public function editar($id = null)
    {

        $car = new Vehiculo();
        $registro['datos_veh']= $car->find($id);

      return view('actualizando',$registro);
     


       return redirect()->to(base_url());
    }
    public function actualizar()
    {

        $car = new Vehiculo();
        $id= $_POST['id'];

        $data = [

            'placa' => $_POST['placa'],
            'vehiculo' => $_POST['vehiculo'],
            'nombreCon' => $_POST['nombreCon'],
            'apellidoCon' => $_POST['apellidoCon'],
            'tiempo' => $_POST['tiempo'],
            'espacio' => $_POST['espacio']
        ];
        $car->update($id,$data);

       return redirect()->to(base_url());
    }





}