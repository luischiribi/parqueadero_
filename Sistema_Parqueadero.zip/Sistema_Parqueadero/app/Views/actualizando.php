<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Actualizar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
</head>

<body>
    <div class="container"><br> <br>
        <div class="container-fluid">
            <h1>Actualizar</h1>
            <form action="<?= base_url('actualizar'); ?>" method="POST">
                <div class="form-group">
                    <input type="number" hidden name="id" value="<?= $datos_veh['id'] ?>">
                    <label for="exampleInputEmail1">placa</label>
                    <input type="text" class="form-control" id="placa" name="placa" value="<?= $datos_veh['placa'] ?>" required aria-describedby="emailHelp">

                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Vehiculo</label>
                    <br>
                    <select name="vehiculo" id="vehiculo">                       
                    <option disabled selected>Selecciona una opción</option>
                    <option value="<?= $datos_veh['vehiculo'] ?>">carro</option>
                    <option value="<?= $datos_veh['vehiculo'] ?>">moto</option>
                    <option value="<?= $datos_veh['vehiculo'] ?>">bicicleta</option>

                 </select>

                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Nombre  conductor</label>
                    <input type="text" class="form-control" id="nombreCon" name="nombreCon" value="<?= $datos_veh['nombreCon'] ?>" required aria-describedby="emailHelp">

                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Apellido  conductor</label>
                    <input type="text" class="form-control" id="apellidoCon" name="apellidoCon" value="<?= $datos_veh['apellidoCon'] ?>" required aria-describedby="emailHelp">


                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Tiempo total</label>
                    <br>
                    <select name="tiempo" id="tiempo">
                    <option disabled selected>Selecciona una opción</option>
                    <option value="<?= $datos_veh['tiempo'] ?>">1-2 horas</option>
                    <option value="<?= $datos_veh['tiempo'] ?>">3-4 horas</option>
                    <option value="<?= $datos_veh['tiempo'] ?>">5-6 horas</option>
                    <option value="<?= $datos_veh['tiempo'] ?>">7-8 horas</option>
                    <option value="<?= $datos_veh['tiempo'] ?>">Más</option>
                 </select>

                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">Tiempo total</label>
                    <br>
                    <select name="espacio" id="espacio">
                    <option disabled selected>Selecciona una opción</option>
                    <option value="<?= $datos_veh['espacio'] ?>">1</option>
                    <option value="<?= $datos_veh['espacio'] ?>">2</option>
                    <option value="<?= $datos_veh['espacio'] ?>">3</option>
                    <option value="<?= $datos_veh['espacio'] ?>">4</option>
                    <option value="<?= $datos_veh['espacio'] ?>">5</option>
                 </select>

                </div>


                <button type="submit" class="btn btn-primary">Actualizar</button>
            </form>
        </div>
    </div>

</body>

</html>