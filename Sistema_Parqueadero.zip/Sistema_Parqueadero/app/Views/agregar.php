<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>agregar</title>		
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
</head>

<body>
<div class="contenedor">
        <nav>
		<ul>
			<li><a href="<?php echo site_url('agregar');?>">Inicio</a></li>
			<li><a href="<?php echo site_url('consultar');?>">Consultar parqueadero</a></li>
	</nav>
    <div class="container"><br> <br>
        <div class="container-fluid">
            <h1>Agregar</h1>
            <form action="insertar" method="POST">
                <div class="form-group">
                    <label for="exampleInputEmail1">placa</label>
                    <input type="text" class="form-control" id="placa" name="placa" required aria-describedby="emailHelp">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">vehiculo</label>
                    <br>
                    <select name="vehiculo" id="vehiculo">
                    <option disabled selected>Selecciona una opción</option>
                    <option value="carro">carro </option>
                    <option value="moto">moto</option>
                    <option value="bicicleta">bicicleta</option>
                    </select> 
                </div>
                
                <div class="form-group">
                    <label for="exampleInputEmail1">nombre del conductor</label>
                    <input type="text" class="form-control" id="nombreCon" name="nombreCon" required aria-describedby="emailHelp">
                </div>
                <div class="form-group">
                    <label for="exampleInputEmail1">apellido del conductor</label>
					<input type="text" class="form-control" id="apellidoCon" name="apellidoCon" required aria-describedby="emailHelp">
                </div>
                <br>	
                 <div class="form-group">
                    <label for="exampleInputEmail1">Tiempo total</label>
                    <br>
                    <select name="tiempo" id="tiempo">
                    <option disabled selected>Selecciona una opción</option>
                    <option value="1-2 horas">1-2 horas </option>
                    <option value="3-4 horas">3-4 horas</option>
                    <option value="5-6 horas">5-6 horas</option>
					<option value="7-8 horas">7-8 horas</option>
					<option value="Más">Más</option>
                    </select> 
                </div>
				<div class="form-group">
                    <label for="exampleInputEmail1">Espacios</label>
                    <br>
                    <select name="espacio" id="espacio">
                    <option disabled selected>Selecciona una opción</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
                    </select> 
                </div>				
                <button type="submit" class="btn btn-primary">Agregar</button>
            </form>
        </div>
    </div>

</body>

</html>